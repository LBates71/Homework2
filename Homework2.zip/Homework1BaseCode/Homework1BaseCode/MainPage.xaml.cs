﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;

using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Globalization; // Provides access to Globalization settings APIs
using Windows.System.UserProfile; // Provides access to user preference setting APIs
using Windows.UI.Xaml.Media.Imaging;
using Windows.Media;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Homework1BaseCode
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }


        private async void LangButton_Click(object sender, RoutedEventArgs e)
        {
            string langToPass = GlobalizationPreferences.Languages.First();
            LanguageObject[] availableLanguages = await OpenFlowerProxy.GetLanguages();
            List<LocalizedName> holdLang;
            string langText = "";
            string nativeText = " ";
            string localText = "";

            for (int i = 0; i < availableLanguages.Length; i = i + 1)
            {
                langText = langText + availableLanguages[i].LanguageId;
                nativeText = nativeText + availableLanguages[i].NativeName;
                holdLang = availableLanguages[i].LocalizedNames;

                for (int y = 0; y < holdLang.Count; y++)
                {
                    localText = localText + holdLang[y].Value;
                }

                if (i < availableLanguages.Length - 1)
                {
                    langText = langText + ", ";
                    nativeText = nativeText + ", ";
                    localText = localText + ", ";
                }
            }
            Language_ID.Text = "Language IDs: " + langText;
            Native_Names.Text = "Native Names: " + nativeText;
            Localized_Names.Text = "Localized Names: " + localText;
        }

        private async void MarketButton_Click(object sender, RoutedEventArgs e)
        {
            string langToPass = GlobalizationPreferences.Languages.First();
            MarketObject[] availableMarkets = await OpenFlowerProxy.GetMarkets();
            string marketText = "";

            for (int i = 0; i < availableMarkets.Length; i = i + 1)
            {
                marketText = marketText + availableMarkets[i].MarketId + '|';
                MarketTextBlock.Text = marketText;
            }
        }

        private async void FlowerButton_Click(object sender, RoutedEventArgs e)
        {            
            FlowerObject[] availableFlowers = await OpenFlowerProxy.GetFlowers();
            string flowerText = "";

            for (int i = 0; i < availableFlowers.Length; i = i + 1)
            {
                flowerText = flowerText + availableFlowers[i].GlobalDisplayName + '|';
                FlowerTextBlock.Text = flowerText;
            }
        }
    }
}