﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace Homework1BaseCode
{
    class OpenFlowerProxy
    {
        public async static Task<LanguageObject[]> GetLanguages()
        {
            string languageUrl = "http://flowerservice20160406025332.azurewebsites.net/languages";
            var http = new HttpClient();
            HttpResponseMessage response = await http.GetAsync(languageUrl);
            string result = await response.Content.ReadAsStringAsync();
            var serializer = new DataContractJsonSerializer(typeof(LanguageObject[]));

            var ms = new MemoryStream(Encoding.UTF8.GetBytes(result));
            var data = (LanguageObject[]) serializer.ReadObject(ms);

            return data;
        }

        public async static Task<MarketObject[]> GetMarkets()
        {
            string marketUrl = "http://flowerservice20160406025332.azurewebsites.net/markets";
            var http = new HttpClient();
            HttpResponseMessage response = await http.GetAsync(marketUrl);
            string result = await response.Content.ReadAsStringAsync();
            var serializer = new DataContractJsonSerializer(typeof(MarketObject[]));

            var ms = new MemoryStream(Encoding.UTF8.GetBytes(result));
            var data = (MarketObject[]) serializer.ReadObject(ms);

            return data;
        }

        public async static Task<FlowerObject[]> GetFlowers()
        {
            string flowerUrl = "http://flowerservice20160406025332.azurewebsites.net/flowers";
            var http = new HttpClient();
            HttpResponseMessage response = await http.GetAsync(flowerUrl);
            string result = await response.Content.ReadAsStringAsync();
            var serializer = new DataContractJsonSerializer(typeof(FlowerObject[]));

            var ms = new MemoryStream(Encoding.UTF8.GetBytes(result));
            var data = (FlowerObject[]) serializer.ReadObject(ms);

            return data;
        }
    }

    [DataContract]
    public class LocalizedName
    {
        [DataMember]
        public string Key { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [DataContract]
    public class LanguageObject
    {
        [DataMember]
        public string ResponseGuid { get; set; }
        [DataMember]
        public string LanguageId { get; set; }
        [DataMember]
        public string UserLangId { get; set; }
        [DataMember]
        public string NativeName { get; set; }
        [DataMember]
        public List<LocalizedName> LocalizedNames { get; set; }
    }

    [DataContract]
    public class MarketName
    {
        [DataMember]
        public string Key { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [DataContract]
    public class MarketObject
    {
        [DataMember]
        public string ResponseGuid { get; set; }
        [DataMember]
        public string MarketId { get; set; }
        [DataMember]
        public string RegionCode { get; set; }
        [DataMember]
        public string LocalizedMarketName { get; set; }
        [DataMember]
        public string GlobalMarketName { get; set; }
        [DataMember]
        public List<MarketName> MarketName { get; set; }
        [DataMember]
        public string Languages { get; set; }
        [DataMember]
        public string UserLangId { get; set; }
    }

    [DataContract]
    public class DisplayName
    {
        [DataMember]
        public string Key { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [DataContract]
    public class PriceInfoOfCurrentBillingRegion
    {
        [DataMember]
        public double Price { get; set; }
        [DataMember]
        public string Currency { get; set; }
        [DataMember]
        public string MarketId { get; set; }
    }

    [DataContract]
    public class PriceInfo
    {
        [DataMember]
        public double Price { get; set; }
        [DataMember]
        public string Currency { get; set; }
        [DataMember]
        public string MarketId { get; set; }
    }

    [DataContract]
    public class FlowerObject
    {
        [DataMember]
        public string ResponseGuid { get; set; }
        [DataMember]
        public string FlowerId { get; set; }
        [DataMember]
        public List<string> OccasionIds { get; set; }
        [DataMember]
        public string PublishDate { get; set; }
        [DataMember]
        public string GlobalDisplayName { get; set; }
        [DataMember]
        public List<DisplayName> DisplayName { get; set; }
        [DataMember]
        public string Languages { get; set; }
        [DataMember]
        public string UserLangId { get; set; }
        [DataMember]
        public List<string> Colors { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string ImageUri { get; set; }
        [DataMember]
        public PriceInfoOfCurrentBillingRegion PriceInfoOfCurrentBillingRegion { get; set; }
        [DataMember]
        public List<PriceInfo> PriceInfos { get; set; }
        [DataMember]
        public List<string> AvaliableMarketIds { get; set; }
    }

}
